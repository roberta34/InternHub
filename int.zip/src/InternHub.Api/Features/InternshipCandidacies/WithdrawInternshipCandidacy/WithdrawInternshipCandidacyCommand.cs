namespace InternHub.Api.Features.InternshipCandidacies.WithdrawInternshipCandidacy;

public sealed record WithdrawInternshipCandidacyCommand(Guid CandidacyId);
